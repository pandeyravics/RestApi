﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication4
{
    public class Record
    {
        public int state_code { get; set; }
        public int district_code { get; set; }
        public int teh_code { get; set; }
        public int blk_code { get; set; }
        public int gp_code { get; set; }
        public int vill_code { get; set; }
        public int sector_code { get; set; }
        public int dept_code { get; set; }
        public int project_code { get; set; }
        public int yr { get; set; }
        public int mnth { get; set; }
        public int dataportmode { get; set; }
        public string modedesc { get; set; }
        public int data_lvl_code { get; set; }
        public decimal cnt1 { get; set; }
        public decimal cnt2 { get; set; }
        public decimal cnt3 { get; set; }
        public decimal cnt4 { get; set; }
        public decimal cnt5 { get; set; }
    }
    public class InputParam
    {
        public int state_code { get; set; }
        public int dept_code { get; set; }
        public int project_code { get; set; }
        public int sec_code { get; set; }
    }
}