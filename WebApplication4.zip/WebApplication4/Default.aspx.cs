﻿using System;
using System.Collections;
using System.Data;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web.Script.Serialization;

namespace WebApplication4
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        CSComClass cc = new CSComClass();
        // Set the values of State Code, Sector Code, Department Code, and Project Code to the respective Variables.
        string State_Code = "9"; //As per "LG" Directory.
        string Sector_Code = "26"; //As provided by DARPAN Dashboard.
        string Department_Code = "170"; //As provided by DARPAN Dashboard.
        string Project_Code = "101583"; //As provided by DARPAN Dashboard.
        DataSet ds;
        //get date range
        string GetDateRangeAPIUrl = "http://164.100.233.90/DarpanREST/api/DateRange";
       
        protected void generateJson_Click1(object sender, EventArgs e)
        {
            // Make the Object of InputParam Class Defined in Record Class.
            var g = new InputParam();
            g.state_code = Convert.ToInt32(State_Code);
            g.sec_code = Convert.ToInt32(Sector_Code);
            g.dept_code = Convert.ToInt32(Department_Code);
            g.project_code = Convert.ToInt32(Project_Code);

            string datefrom = "01/01/1900";
            string dateto = "01/01/1900";
            try
            {
                DataSet ds2 = new DataSet();
                int cnt = 0;

                ds2 = cc.ConvertJsonToDatatable(ApiConnectWithDaterange(g));

                cnt = ds2.Tables[0].Rows.Count;
                if (cnt > 0)
                {
                    string op = "";
                    op = ds2.Tables[0].Rows[0].ItemArray[0].ToString();

                    if (op == "0" | op == "99" | op.Length > 10)
                    {
                        lblResponse.Text = "No Date Found for Date Range";
                        return;
                    }
                    else if (cnt == 1)
                    {
                        datefrom = ds2.Tables[0].Rows[0].ItemArray[1].ToString();
                        dateto = ds2.Tables[0].Rows[0].ItemArray[1].ToString();
                        lblResponse.Text = dateto;
                    }
                    else
                    {
                        datefrom = ds2.Tables[0].Rows[0].ItemArray[1].ToString();
                        dateto = ds2.Tables[0].Rows[cnt - 1].ItemArray[1].ToString();
                        lblResponse.Text = dateto;
                    }
                }

                // If Step 1 executed successfully, then Step 2 executes.
                // Step 2 requires a Stored Procedures, which fetch data from your DataBase.
                // "datefrom" And "dateto" values of Step 1 is used as the input parameter in Step 2.
                // In this case, "Save_Key_Demo" is used as Stored Procedure Name.

                // Step 2: Call Method to PUSH DATA TO DARPAN DASHBOARD "ApiConnect"


            }
            catch (Exception ex)
            {
                object response = null;
                var r = new { Status = "0", Message = ex.Message };
                response = r;

                // Inset/Update the existing record with the exception message.
                //` vdsssss   LogEntry(datefrom, dateto, ex.Message);
            }
        }
        // Step 1: Method to Get Date Range
        protected string ApiConnectWithDaterange(InputParam api)
        {
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                httpClient.Timeout = TimeSpan.FromMinutes(60.0);

                var f = new InputParam();
                f = api;

                var inputContent = (new JavaScriptSerializer() { MaxJsonLength = 2147483644 }).Serialize(f);
                var buffer = Encoding.UTF8.GetBytes(inputContent);
                var byteContent = new ByteArrayContent(buffer);
                byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                HttpResponseMessage response = httpClient.PostAsync(GetDateRangeAPIUrl, byteContent).Result;
                string xml = null;

                if (response.IsSuccessStatusCode)
                {
                    xml = response.Content.ReadAsStringAsync().Result;

                    if (xml.Equals("null"))
                        xml = null;
                }
                else
                {
                    xml = response.Content.ReadAsStringAsync().Result;
                }

                return xml;
            }
            catch (Exception ex)
            {
                object response = null;
                var r = new { Status = "0", Message = ex.Message };
                response = r;
                return response.ToString();
            }
        }
    }
}