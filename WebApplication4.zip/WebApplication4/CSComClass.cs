﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace WebApplication4
{
    public class CSComClass
    {
        SqlConnection conn;
        SqlCommand mCom;
        SqlDataAdapter mDa;
        public DataSet ConvertJsonToDatatable(string jsonString)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable("Dash");
            ds.Tables.Add(dt);
            string s = "{" + "\"" + "RetDMDashCaption" + "\"" + ":";
            jsonString = jsonString.Replace(s, "").Trim('}');
            string[] jsonParts = Regex.Split(jsonString.Replace("[", "").Replace("]", ""), "},{");
            List<string> dtColumns = new List<string>();

            foreach (string jp in jsonParts)
            {
                string[] propData = Regex.Split(jp.Replace("{", "").Replace("}", ""), ",");

                foreach (string rowData in propData)
                {
                    try
                    {
                        int idx = rowData.IndexOf(":");
                        string n = rowData.Substring(0, idx - 1);
                        string v = rowData.Substring(idx + 1);

                        if (!dtColumns.Contains(n))
                        {
                            dtColumns.Add(n.Replace("\"", ""));
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new Exception(string.Format("Error Parsing Column Name : {0}", rowData));
                    }
                }

                break;
            }

            foreach (string c in dtColumns)
            {
                dt.Columns.Add(c);
            }

            foreach (string jp in jsonParts)
            {
                string[] propData = Regex.Split(jp.Replace("{", "").Replace("}", ""), ",");
                DataRow nr = dt.NewRow();

                foreach (string rowData in propData)
                {
                    try
                    {
                        int idx = rowData.IndexOf(":");
                        string n = rowData.Substring(0, idx - 1).Replace("\"", "");
                        string v = rowData.Substring(idx + 1).Replace("\"", "");
                        nr[n] = v;
                    }
                    catch (Exception ex)
                    {
                        continue;
                    }
                }

                dt.Rows.Add(nr);
            }

            return ds;
        }
    }
}